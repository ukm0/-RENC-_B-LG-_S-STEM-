﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class OgrenciSil : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        int id;

        if (int.TryParse(Request.QueryString["OGRID"], out id))
        {
            
        }
        else
        {
           
        }


        DataSetTableAdapters.TBL_OGRENCİTableAdapter dt = new
         DataSetTableAdapters.TBL_OGRENCİTableAdapter();
        dt.OgrenciSil(id);
        Response.Redirect("Default.aspx");
    }
}