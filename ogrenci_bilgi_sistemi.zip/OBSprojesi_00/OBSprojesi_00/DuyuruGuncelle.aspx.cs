﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DuyuruGuncelle : System.Web.UI.Page
{ 
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (int.TryParse(Request.QueryString["DUYURUID"], out int id))
            {
                DataSetTableAdapters.TBL_DUYURULARTableAdapter dt = new DataSetTableAdapters.TBL_DUYURULARTableAdapter();

                var duyuruListesi = dt.DuyuruSec(id);

                if (duyuruListesi != null && duyuruListesi.Count > 0)
                {
                    TxtDuyuruID.Text = id.ToString();
                    TxtDuyuruBaslik.Text = duyuruListesi[0].DUYURUBASLIK;
                    TextArea1.Value = duyuruListesi[0].DUYURUICERIK;
                }
            }
        }
    }
   
    protected void Button1_Click(object sender, EventArgs e)
        
    {
        DataSetTableAdapters.TBL_DUYURULARTableAdapter dt = 
            new DataSetTableAdapters.TBL_DUYURULARTableAdapter();
        dt.DuyuruGuncelle(TxtDuyuruBaslik.Text, TextArea1.Value , Convert.ToInt32(TxtDuyuruID.Text));
        Response.Redirect("DuyuruListesi.aspx");


    }
}
