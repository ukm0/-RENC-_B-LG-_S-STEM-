﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class OgrenciDefault : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Textbox1.Text = Session["OGRNUMARA"].ToString();
        int ogrenciNumara;
        if (int.TryParse(Textbox1.Text, out ogrenciNumara))
        {
            DataSetTableAdapters.TBL_OGRENCİTableAdapter dt = new DataSetTableAdapters.TBL_OGRENCİTableAdapter();
            Textbox2.Text = "AD SOYAD: " + dt.OgrenciPaneliGetir(ogrenciNumara)[0].OGRAD + " " + dt.OgrenciPaneliGetir(ogrenciNumara)[0].OGRSOYAD;
            Textbox3.Text = "MAİL ADRESİ: " + dt.OgrenciPaneliGetir(ogrenciNumara)[0].OGRMAİL;
            Textbox4.Text = "ŞİFRE: " + dt.OgrenciPaneliGetir(ogrenciNumara)[0].OGRSIFRE;
            Textbox5.Text = "TELEFON: " + dt.OgrenciPaneliGetir(ogrenciNumara)[0].OGRTELEFON;
        }
        else
        {
            // Uygun bir sayısal değer elde edilemedi, hata işleme yapılabilir.
            // Örneğin, kullanıcıya hata mesajı gösterilebilir.
        }
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("OgrenciGuncelle2.aspx?OGRNUMARA=" + Textbox1.Text);
    }
}